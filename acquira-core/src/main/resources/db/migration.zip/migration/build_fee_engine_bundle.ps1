# Generates FEE_ENGINE_CONSOLIDATED.sql from its source migrations.
# Re-run this after editing any source file; do not hand-edit the bundle.
$ErrorActionPreference = 'Stop'
$mig = "C:\Users\sivag\Desktop\cms\Acquira\acquira-core\src\main\resources\db\migration"
$out = Join-Path $mig "FEE_ENGINE_CONSOLIDATED.sql"

# Prerequisites: not requested, but the bundled rate cards cannot run without them.
$prereq = @(
  "V2026_07_15_01__region_readiness_uae.sql",
  "V2026_07_31_02__multi_country_interchange_engine.sql"
)

# The 23 requested files, in spring.sql.init.schema-locations order.
# V2026_08_11_01/02 are not in that property yet, so they go last by filename.
$files = @(
  "V2026_07_05_01__interchange_scheme_fees.sql",
  "V2026_07_07_01__mcc_rate_card_uae.sql",
  "V2026_07_07_04__intl_debit_interchange.sql",
  "V2026_07_31_03__rate_card_bahrain.sql",
  "V2026_07_31_04__rate_card_oman.sql",
  "V2026_07_31_05__rate_card_egypt.sql",
  "V2026_08_07_01__integration_schedule_precondition.sql",
  "V2026_08_08_01__remove_executive_dashboard_v2_menu.sql",
  "V2026_08_08_02__volume_revenue_summary_covering_indexes.sql",
  "V2026_08_08_03__tenant_input_format.sql",
  "V2026_08_08_04__tenant_home_country_backfill.sql",
  "V2026_08_08_05__benefit_rate_card_bh.sql",
  "V2026_08_08_06__bin_mapping_menu.sql",
  "V2026_08_09_01__ref_bin_range.sql",
  "V2026_08_09_02__mpe_staging.sql",
  "V2026_08_09_03__ref_bin_range_19_digits.sql",
  "V2026_08_09_04__interchange_normalization.sql",
  "V2026_08_10_01__multi_currency_precision_and_fee_resolution.sql",
  "V2026_08_10_02__meeza_and_benefit_international.sql",
  "V2026_08_10_03__feed_amount_contract.sql",
  "V2026_08_10_04__approve_uae_derived_rates_and_ticket_buckets.sql",
  "V2026_08_11_01__sales_agent_target.sql",
  "V2026_08_11_02__sales_pulse_menus.sql"
)

foreach ($f in ($prereq + $files)) {
  if (-not (Test-Path (Join-Path $mig $f))) { throw "missing source file: $f" }
}

$sb = New-Object System.Text.StringBuilder
function Add-Line($t) { [void]$sb.AppendLine($t) }

Add-Line @'
-- ============================================================================
-- Acquira - Fee Engine + Multi-Country Onboarding Consolidated Bundle
-- Generated from source migrations by build_fee_engine_bundle.ps1 (same
-- directory as this file). DO NOT HAND-EDIT:
-- edit the source migration and regenerate, or the bundle and the per-file
-- scripts drift apart.
--
-- WHAT THIS FILE IS
-- -----------------
-- A single-file concatenation, for a ONE-TIME psql run against an EXISTING
-- database, of the 23 migrations covering the fee engine, the BH/OM/EG/UAE rate
-- cards, multi-currency precision, BIN reference data and the sales-target
-- screens. Same model as ALL_MIGRATIONS_CONSOLIDATED.sql (which stops at
-- V2026_07_13_01) and PROD_GAP_CONSOLIDATED.sql - this one covers the later
-- fee-engine work those two predate.
--
-- schema.sql is NOT included. This bundle is ALTER/INSERT-only and assumes the
-- core tables (tenant, ref_country, fact_transaction, the sum_* rollups,
-- sys_menu / sys_group_menu) already exist.
--
-- PREREQUISITES INCLUDED (section 0)
-- ----------------------------------
-- Two migrations that were NOT in the requested list are prepended, because the
-- requested files cannot run without them:
--   V2026_07_15_01  adds interchange_rate_local.country_code / cap_currency_code
--                   and tenant.home_country_code.
--   V2026_07_31_02  adds country_code to scheme_fee_rate / mcc_sector_map, makes
--                   tenant_id NULLABLE on all three config tables, and converts
--                   the existing AE rows to country defaults (tenant_id -> NULL).
-- Without the nullable tenant_id, every BH/OM/EG rate row (all tenant_id NULL)
-- fails to insert. Without the AE tenant_id -> NULL conversion, the scheme-fee
-- copy at the end of each country card reads
-- "WHERE country_code = 'AE' AND tenant_id IS NULL", matches zero rows, and each
-- new country silently gets NO scheme-fee grid - which V2026_08_10_04 would then
-- mark APPROVED as an empty set. Both are idempotent, so on a database that has
-- already applied them section 0 is a no-op.
--
-- RE-RUN SAFETY
-- -------------
-- Every statement is idempotent, unchanged from the source files:
--   * DDL uses IF NOT EXISTS, or DROP-then-ADD for constraints.
--   * Inserts use ON CONFLICT DO NOTHING or a WHERE NOT EXISTS guard. Note the
--     rate-card guards are COARSE by design - "seed only if this country has no
--     rows at all" - so a second run never duplicates a card and never clobbers
--     an operator's in-UI rate edit.
--   * Corrections are absolute-value UPDATEs; re-running sets the same value.
--   * The reseed blocks (V2026_07_05_01 / V2026_07_07_01 / V2026_07_07_04 scheme
--     grid and priority-50 MCC rows) are DELETE-then-INSERT scoped to the ACQ
--     tenant's own rows, so they converge rather than accumulate.
-- No ON CONFLICT clause names an arbiter that may be missing: the two places
-- where that trap exists (mcc_sector_map, scheme_fee_rate, both re-keyed by
-- V2026_07_31_02) deliberately use NOT EXISTS instead.
--
-- NOT IDEMPOTENT IN THE STRICT SENSE - one statement, called out for review:
--   V2026_07_31_02 section 5 (the AE tenant_id -> NULL conversion) is guarded by
--   schema_migration_log so it runs EXACTLY ONCE. If you truncate that table the
--   conversion runs again and would null out any per-tenant override added since.
--
-- ORDER DEPENDENCIES PRESERVED
-- ----------------------------
--   V2026_07_15_01 -> V2026_07_31_02 -> the three country rate cards.
--   V2026_07_07_01 -> V2026_07_07_04 (01 seeds USD caps, 04 converts them to AED).
--   V2026_08_10_01 -> V2026_08_10_02 -> V2026_08_10_04 (flat_fee / rate_status
--     columns, then the rows that use them, then the business sign-off that
--     promotes them out of PLACEHOLDER).
--
-- HOW TO RUN
-- ----------
--   psql -v ON_ERROR_STOP=1 --single-transaction -f FEE_ENGINE_CONSOLIDATED.sql "%DB_URL%"
--
-- Use --single-transaction: a failure partway through then rolls the whole run
-- back rather than leaving a half-applied bundle.
--
-- MAINTENANCE WINDOW: V2026_08_10_01 section 1 changes numeric scale on the fact
-- and summary tables, which Postgres implements as a full table REWRITE on every
-- partition. On a production-sized warehouse this is the slow part of the bundle
-- and takes an ACCESS EXCLUSIVE lock. Everything else is fast.
--
-- BACKFILL: fees are computed at ingest, so rate changes here do not touch
-- history. Re-ingest the affected months to reprice them.
-- ============================================================================

-- Audit log. Created first: several bundled files write to it, and
-- V2026_07_31_02's one-time conversion reads it as its run-once guard.
CREATE TABLE IF NOT EXISTS schema_migration_log (
    filename    VARCHAR(200) PRIMARY KEY,
    applied_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

'@

function Add-File($name, $banner) {
  $body = [System.IO.File]::ReadAllText((Join-Path $mig $name))
  Add-Line ""
  Add-Line "-- ############################################################################"
  Add-Line "-- $banner"
  Add-Line "-- ############################################################################"
  Add-Line $body.TrimEnd()
  # Only the files that do not already log themselves get a log line appended,
  # so apply_migrations.bat can skip them on a later run.
  if ($body -notmatch [regex]::Escape("schema_migration_log (filename) VALUES ('$name')")) {
    Add-Line ""
    Add-Line "INSERT INTO schema_migration_log (filename) VALUES ('$name') ON CONFLICT (filename) DO NOTHING;"
  }
  Add-Line ""
}

$i = 0
foreach ($f in $prereq) { $i++; Add-File $f "PREREQUISITE $i/$($prereq.Count): $f" }
$i = 0
foreach ($f in $files)  { $i++; Add-File $f "FILE $i/$($files.Count): $f" }

Add-Line "-- ============================================================================"
Add-Line "-- End of bundle. $($prereq.Count) prerequisites + $($files.Count) migrations."
Add-Line "-- ============================================================================"

$enc = New-Object System.Text.UTF8Encoding($false)   # no BOM - psql chokes on one
[System.IO.File]::WriteAllText($out, $sb.ToString(), $enc)
Write-Output "wrote $out"
Write-Output ("{0:N1} KB, {1} lines" -f ((Get-Item $out).Length/1KB), (Get-Content $out | Measure-Object -Line).Lines)
